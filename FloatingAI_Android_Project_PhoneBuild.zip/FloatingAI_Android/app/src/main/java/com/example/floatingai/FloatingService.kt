package com.example.floatingai

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val history = mutableListOf<Pair<String, String>>()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "floating_ai")
                .setContentTitle("Floating AI يعمل")
                .setContentText("اضغط على الفقاعة لفتح المساعد")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Floating AI يعمل")
                .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()
        }
        startForeground(7, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("floating_ai", "Floating AI", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "AI"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF4557D8.toInt())
            elevation = 12f
            setPadding(14, 14, 14, 14)
        }
        val p = WindowManager.LayoutParams(
            dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180) }
        var downX = 0; var downY = 0; var startX = 0; var startY = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX.toInt(); downY = e.rawY.toInt(); startX = p.x; startY = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX.toInt() - downX; val dy = e.rawY.toInt() - downY
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                    p.x = startX + dx; p.y = startY + dy; wm.updateViewLayout(b, p); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> true
            }
        }
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFF8F9FF.toInt())
            elevation = 18f
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = TextView(this).apply {
            text = "مساعد AI"
            textSize = 18f
            setTextColor(0xFF182033.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { removePanel() }
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(42)))
        val chat = TextView(this).apply {
            text = "مرحباً! اكتب سؤالك وسأجيبك."
            textSize = 14f
            setTextColor(0xFF202638.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
        }
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "اكتب رسالتك..."
            textSize = 14f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
        }
        val send = Button(this).apply { text = "إرسال" }
        inputRow.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        inputRow.addView(send, LinearLayout.LayoutParams(dp(76), dp(52)))
        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(inputRow)
        val params = WindowManager.LayoutParams(
            dp(320), dp(390), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(100); softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
        send.setOnClickListener {
            val question = input.text.toString().trim()
            if (question.isEmpty()) return@setOnClickListener
            input.setText("")
            append(chat, scroll, "أنت: $question")
            append(chat, scroll, "AI: جارٍ التفكير...")
            askAI(question) { answer ->
                runOnUiThread {
                    val old = chat.text.toString()
                    chat.text = old.replace("AI: جارٍ التفكير...", "AI: $answer")
                    scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                }
            }
        }
        panel = root
        panelParams = params
        wm.addView(root, params)
    }

    private fun append(chat: TextView, scroll: ScrollView, line: String) {
        chat.text = chat.text.toString() + "\n\n" + line
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun askAI(question: String, done: (String) -> Unit) {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) { done("أضف مفتاح API من التطبيق الرئيسي."); return }
        history.add("user" to question)
        val recent = history.takeLast(10).joinToString("\n") { "${it.first}: ${it.second}" }
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                }
                val payload = JSONObject()
                    .put("model", "gpt-4.1-mini")
                    .put("instructions", "You are a helpful assistant. Reply in the language used by the user.")
                    .put("input", recent)
                    .toString()
                connection.outputStream.use { it.write(payload.toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) {
                    val msg = try { JSONObject(body).optJSONObject("error")?.optString("message") ?: body } catch (_: Exception) { body }
                    done("خطأ API ($code): $msg")
                } else {
                    val json = JSONObject(body)
                    val out = StringBuilder()
                    val arr = json.optJSONArray("output")
                    if (arr != null) for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (item.optString("type") == "message") {
                            val content = item.optJSONArray("content") ?: continue
                            for (j in 0 until content.length()) {
                                val part = content.optJSONObject(j) ?: continue
                                if (part.optString("type") == "output_text") out.append(part.optString("text"))
                            }
                        }
                    }
                    val answer = out.toString().ifBlank { "لم يصل نص في الاستجابة." }
                    history.add("assistant" to answer)
                    done(answer)
                }
            } catch (e: Exception) {
                done("تعذر الاتصال: ${e.localizedMessage ?: "تحقق من الإنترنت ومفتاح API"}")
            } finally { connection?.disconnect() }
        }
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelParams = null
    }

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
