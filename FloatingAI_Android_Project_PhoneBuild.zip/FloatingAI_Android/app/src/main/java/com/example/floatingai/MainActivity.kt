package com.example.floatingai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var keyInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "Floating AI"
            textSize = 28f
            setTextColor(0xFF182033.toInt())
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "مساعد ذكاء اصطناعي عائم يعمل فوق التطبيقات والألعاب. أدخل مفتاح API الخاص بك ثم فعّل الفقاعة."
            textSize = 16f
            setTextColor(0xFF30384A.toInt())
            setPadding(0, 18, 0, 18)
        }
        keyInput = EditText(this).apply {
            hint = "OpenAI API key (sk-...)"
            textSize = 14f
            singleLine = true
            inputType = passwordInputType()
            setText(getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", ""))
        }
        val save = Button(this).apply {
            text = "حفظ مفتاح API"
            setOnClickListener {
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putString("api_key", keyInput.text.toString().trim()).apply()
                status.text = "تم حفظ المفتاح على هذا الهاتف."
            }
        }
        val permission = Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "إذن الظهور العائم مفعّل."
            }
        }
        val start = Button(this).apply {
            text = "تشغيل الفقاعة العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "فعّل إذن الظهور فوق التطبيقات أولاً."
                    return@setOnClickListener
                }
                val key = keyInput.text.toString().trim()
                if (key.isEmpty()) {
                    status.text = "أدخل مفتاح OpenAI API أولاً."
                    return@setOnClickListener
                }
                getSharedPreferences("settings", MODE_PRIVATE).edit().putString("api_key", key).apply()
                val i = Intent(this@MainActivity, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                status.text = "تم طلب تشغيل الفقاعة. يمكنك الآن فتح Yalla Ludo."
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف الفقاعة"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)); status.text = "تم إيقاف الخدمة." }
        }
        status = TextView(this).apply {
            text = "ملاحظة: استخدام OpenAI API قد يتطلب رصيداً مدفوعاً منفصلاً عن اشتراك ChatGPT."
            textSize = 13f
            setTextColor(0xFF6B7280.toInt())
            setPadding(0, 16, 0, 0)
        }
        listOf(title, intro, keyInput, save, permission, start, stop, status).forEach {
            box.addView(it, LinearLayout.LayoutParams(-1, if (it == title) 56 else -2).apply {
                bottomMargin = 10
            })
        }
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun passwordInputType(): Int = android.text.InputType.TYPE_CLASS_TEXT or
        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
}
